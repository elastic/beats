# Welcome to Agent 8.0.0



## Getting Started

To get started with Agent, you need to set up Elasticsearch on
your localhost first. After that, start Agent with:

     ./agent -c agent.yml -e

This will start Agent and send the data to your Elasticsearch
instance. To load the dashboards for Agent into Kibana, run:

    ./agent setup -e

For further steps visit the
[Getting started](https://www.elastic.co/guide/en/beats/agent/master/agent-getting-started.html) guide.

## Documentation

Visit [Elastic.co Docs](https://www.elastic.co/guide/en/beats/agent/master/index.html)
for the full Agent documentation.

## Release notes

https://www.elastic.co/guide/en/beats/libbeat/master/release-notes-8.0.0.html
