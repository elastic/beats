# Delete and stop the service if it already exists.
if (Get-Service agent -ErrorAction SilentlyContinue) {
  $service = Get-WmiObject -Class Win32_Service -Filter "name='agent'"
  $service.StopService()
  Start-Sleep -s 1
  $service.delete()
}

$workdir = Split-Path $MyInvocation.MyCommand.Path

# Create the new service.
New-Service -name agent `
  -displayName Agent `
  -binaryPathName "`"$workdir\agent.exe`" -c `"$workdir\agent.yml`" -path.home `"$workdir`" -path.data `"C:\ProgramData\agent`" -path.logs `"C:\ProgramData\agent\logs`""

# Attempt to set the service to delayed start using sc config.
Try {
  Start-Process -FilePath sc.exe -ArgumentList 'config agent start=delayed-auto'
}
Catch { Write-Host "An error occured setting the service to delayed start." -ForegroundColor Red }
